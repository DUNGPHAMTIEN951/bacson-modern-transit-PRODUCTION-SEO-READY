# Danh mục Ảnh chụp Giao diện Toàn diện (Screenshot Index)

Bộ tài liệu này chứa toàn bộ các ảnh chụp thực tế từ website được kết xuất qua trình duyệt Chromium:

| TT | Đường dẫn tệp | Viewport | Phân đoạn / Trạng thái | Mô tả chi tiết |
| :-: | :--- | :--- | :--- | :--- |
| 1 | `full-page/01-home-desktop-1920-full.png` | `1920x1080` | **Full Homepage** | Complete full-page render at desktop-1920 with all sections, footer, and brand palette |
| 2 | `full-page/02-home-desktop-1440-full.png` | `1440x900` | **Full Homepage** | Complete full-page render at desktop-1440 with all sections, footer, and brand palette |
| 3 | `full-page/03-home-tablet-1024-full.png` | `1024x1366` | **Full Homepage** | Complete full-page render at tablet-1024 with all sections, footer, and brand palette |
| 4 | `full-page/04-home-mobile-390-full.png` | `390x844` | **Full Homepage** | Complete full-page render at mobile-390 with all sections, footer, and brand palette |
| 5 | `full-page/05-home-mobile-360-full.png` | `360x800` | **Full Homepage** | Complete full-page render at mobile-360 with all sections, footer, and brand palette |
| 6 | `hero/hero-desktop-1920.png` | `1920x1080` | **Hero Section** | Dedicated hero review showing slogan 'Sơn La những chuyến đi', supporting line, CTA buttons, and bus photo |
| 7 | `hero/hero-desktop-1440.png` | `1440x900` | **Hero Section** | Dedicated hero review showing slogan 'Sơn La những chuyến đi', supporting line, CTA buttons, and bus photo |
| 8 | `hero/hero-tablet.png` | `1024x1366` | **Hero Section** | Dedicated hero review showing slogan 'Sơn La những chuyến đi', supporting line, CTA buttons, and bus photo |
| 9 | `hero/hero-mobile-390.png` | `390x844` | **Hero Section** | Dedicated hero review showing slogan 'Sơn La những chuyến đi', supporting line, CTA buttons, and bus photo |
| 10 | `hero/hero-mobile-360.png` | `360x800` | **Hero Section** | Dedicated hero review showing slogan 'Sơn La những chuyến đi', supporting line, CTA buttons, and bus photo |
| 11 | `sections/desktop/01-header.png` | `1440x900` | **Header Navigation** | Desktop 1440px section capture for Header Navigation |
| 12 | `sections/desktop/02-hero.png` | `1440x900` | **Hero Section** | Desktop 1440px section capture for Hero Section |
| 13 | `sections/desktop/03-quickbar.png` | `1440x900` | **QuickBar Summary** | Desktop 1440px section capture for QuickBar Summary |
| 14 | `sections/desktop/04-brand-story.png` | `1440x900` | **Brand Story & 4 Journey Stages** | Desktop 1440px section capture for Brand Story & 4 Journey Stages |
| 15 | `sections/desktop/05-schedule.png` | `1440x900` | **Daily Schedule Cards** | Desktop 1440px section capture for Daily Schedule Cards |
| 16 | `sections/desktop/06-fares.png` | `1440x900` | **Fare Table & Disclaimers** | Desktop 1440px section capture for Fare Table & Disclaimers |
| 17 | `sections/desktop/07-route-timeline.png` | `1440x900` | **Route Timeline & Major Stops** | Desktop 1440px section capture for Route Timeline & Major Stops |
| 18 | `sections/desktop/08-son-la-story.png` | `1440x900` | **Sơn La Sense of Place Editorial** | Desktop 1440px section capture for Sơn La Sense of Place Editorial |
| 19 | `sections/desktop/09-gallery.png` | `1440x900` | **Fleet & Cabin Photo Gallery** | Desktop 1440px section capture for Fleet & Cabin Photo Gallery |
| 20 | `sections/desktop/10-amenities.png` | `1440x900` | **Coach Amenities & Services** | Desktop 1440px section capture for Coach Amenities & Services |
| 21 | `sections/desktop/11-cargo.png` | `1440x900` | **Cargo Delivery Service & 4 Steps** | Desktop 1440px section capture for Cargo Delivery Service & 4 Steps |
| 22 | `sections/desktop/12-why-us.png` | `1440x900` | **Why Choose Bắc Sơn Cường Nguyệt** | Desktop 1440px section capture for Why Choose Bắc Sơn Cường Nguyệt |
| 23 | `sections/desktop/13-offices-maps.png` | `1440x900` | **Offices & Interactive Google Maps** | Desktop 1440px section capture for Offices & Interactive Google Maps |
| 24 | `sections/desktop/14-credentials.png` | `1440x900` | **Legal Transport License Credentials** | Desktop 1440px section capture for Legal Transport License Credentials |
| 25 | `sections/desktop/15-faq.png` | `1440x900` | **Frequently Asked Questions** | Desktop 1440px section capture for Frequently Asked Questions |
| 26 | `sections/desktop/16-final-cta.png` | `1440x900` | **Final Call to Action Banner** | Desktop 1440px section capture for Final Call to Action Banner |
| 27 | `sections/desktop/17-footer.png` | `1440x900` | **Footer & Legal Info** | Desktop 1440px section capture for Footer & Legal Info |
| 28 | `sections/mobile/01-header.png` | `390x844` | **Header Navigation** | Mobile 390px section capture for Header Navigation |
| 29 | `sections/mobile/02-hero.png` | `390x844` | **Hero Section** | Mobile 390px section capture for Hero Section |
| 30 | `sections/mobile/03-quickbar.png` | `390x844` | **QuickBar Summary** | Mobile 390px section capture for QuickBar Summary |
| 31 | `sections/mobile/04-brand-story.png` | `390x844` | **Brand Story & 4 Journey Stages** | Mobile 390px section capture for Brand Story & 4 Journey Stages |
| 32 | `sections/mobile/05-schedule.png` | `390x844` | **Daily Schedule Cards** | Mobile 390px section capture for Daily Schedule Cards |
| 33 | `sections/mobile/06-fares.png` | `390x844` | **Fare Table & Disclaimers** | Mobile 390px section capture for Fare Table & Disclaimers |
| 34 | `sections/mobile/07-route-timeline.png` | `390x844` | **Route Timeline & Major Stops** | Mobile 390px section capture for Route Timeline & Major Stops |
| 35 | `sections/mobile/08-son-la-story.png` | `390x844` | **Sơn La Sense of Place Editorial** | Mobile 390px section capture for Sơn La Sense of Place Editorial |
| 36 | `sections/mobile/09-gallery.png` | `390x844` | **Fleet & Cabin Photo Gallery** | Mobile 390px section capture for Fleet & Cabin Photo Gallery |
| 37 | `sections/mobile/10-amenities.png` | `390x844` | **Coach Amenities & Services** | Mobile 390px section capture for Coach Amenities & Services |
| 38 | `sections/mobile/11-cargo.png` | `390x844` | **Cargo Delivery Service & 4 Steps** | Mobile 390px section capture for Cargo Delivery Service & 4 Steps |
| 39 | `sections/mobile/12-why-us.png` | `390x844` | **Why Choose Bắc Sơn Cường Nguyệt** | Mobile 390px section capture for Why Choose Bắc Sơn Cường Nguyệt |
| 40 | `sections/mobile/13-offices-maps.png` | `390x844` | **Offices & Interactive Google Maps** | Mobile 390px section capture for Offices & Interactive Google Maps |
| 41 | `sections/mobile/14-credentials.png` | `390x844` | **Legal Transport License Credentials** | Mobile 390px section capture for Legal Transport License Credentials |
| 42 | `sections/mobile/15-faq.png` | `390x844` | **Frequently Asked Questions** | Mobile 390px section capture for Frequently Asked Questions |
| 43 | `sections/mobile/16-final-cta.png` | `390x844` | **Final Call to Action Banner** | Mobile 390px section capture for Final Call to Action Banner |
| 44 | `sections/mobile/17-footer.png` | `390x844` | **Footer & Legal Info** | Mobile 390px section capture for Footer & Legal Info |
| 45 | `interactions/contact/call-normal.png` | `1440x900` | **Hero Call Button (Normal)** | Sunset terracotta button in resting state with subtle 4s pulse-ring animation |
| 46 | `interactions/contact/call-hover.png` | `1440x900` | **Hero Call Button (Hover)** | Button lifted -2px with darker terracotta background and elevated shadow |
| 47 | `interactions/contact/call-focus.png` | `1440x900` | **Hero Call Button (Focus)** | Keyboard focus outline in mountain-teal ring |
| 48 | `interactions/contact/call-active.png` | `1440x900` | **Hero Call Button (Active)** | Tactile active click state scaled down to 0.98 |
| 49 | `interactions/contact/zalo-normal.png` | `1440x900` | **Hero Zalo Button (Normal)** | Mountain-teal border and text on white surface with message icon |
| 50 | `interactions/contact/zalo-hover.png` | `1440x900` | **Hero Zalo Button (Hover)** | Soft teal background tint #E8F2F4 with -2px lift |
| 51 | `interactions/contact/zalo-focus.png` | `1440x900` | **Hero Zalo Button (Focus)** | Keyboard focus outline ring |
| 52 | `interactions/contact/zalo-active.png` | `1440x900` | **Hero Zalo Button (Active)** | Tactile active press feedback scaled to 0.98 |
| 53 | `interactions/contact/sticky-bar-normal.png` | `390x844` | **Sticky Mobile CTA Bar (Normal)** | Dual contact action bar with GỌI ĐẶT VÉ (terracotta) and CHAT ZALO (mountain-teal) |
| 54 | `mobile/menu-closed.png` | `390x844` | **Mobile Navigation (Closed)** | Mobile viewport top area with hamburger button closed |
| 55 | `mobile/menu-open.png` | `390x844` | **Mobile Navigation (Open)** | Full mobile drawer menu open showing all links, logo, and quick booking CTA |
| 56 | `interactions/faq-open.png` | `1440x900` | **FAQ Accordion (Open)** | FAQ panel with expanded question item showing smooth accordion transition |
| 57 | `interactions/faq-closed.png` | `1440x900` | **FAQ Accordion (Closed)** | FAQ panel with all items collapsed |
| 58 | `maps/maps-desktop.png` | `1440x900` | **Google Maps Section (Desktop)** | Offices section showing dual interactive Google Maps for Bến xe Mỹ Đình (Hà Nội) and 03 Nguyễn Trãi (Sơn La) |
| 59 | `maps/maps-mobile.png` | `390x844` | **Google Maps Section (Mobile)** | Mobile view of terminal office addresses and interactive map embeds |
| 60 | `gallery/gallery-desktop.png` | `1440x900` | **Gallery Section (Desktop)** | Grid layout of real bus and cabin interior photography with zoom triggers |
| 61 | `gallery/gallery-lightbox.png` | `1440x900` | **Gallery Lightbox (Modal)** | Full-screen photo modal overlay with navigation controls and captions |
| 62 | `gallery/gallery-mobile.png` | `390x844` | **Gallery Section (Mobile)** | Mobile photo gallery layout with touch-friendly cards |
| 63 | `mobile/sticky-top-content.png` | `390x844` | **Sticky CTA (Top of Page)** | Sticky CTA overlaying initial content without blocking important interaction points |
| 64 | `mobile/sticky-mid-page.png` | `390x844` | **Sticky CTA (Mid Page)** | Sticky CTA visible while browsing mid-page schedule and fares |
| 65 | `mobile/sticky-near-footer.png` | `390x844` | **Sticky CTA (Near Footer)** | Sticky CTA transition above footer with safe bottom padding |
| 66 | `desktop-scroll/01-top.png` | `1440x900` | **Scroll Position: 01-top** | Top viewport showing Header and Hero |
| 67 | `desktop-scroll/02-quarter.png` | `1440x900` | **Scroll Position: 02-quarter** | Quarter scroll showing Brand Story and Journey Stages |
| 68 | `desktop-scroll/03-middle.png` | `1440x900` | **Scroll Position: 03-middle** | Middle scroll showing Schedule, Fares, and Route Timeline |
| 69 | `desktop-scroll/04-three-quarter.png` | `1440x900` | **Scroll Position: 04-three-quarter** | Three-quarter scroll showing Sơn La Story, Gallery, and Amenities |
| 70 | `desktop-scroll/05-bottom.png` | `1440x900` | **Scroll Position: 05-bottom** | Bottom viewport showing Google Maps, FAQ, Final CTA, and Footer |
| 71 | `mobile-scroll/01-top.png` | `390x844` | **Scroll Position: 01-top** | Mobile top viewport showing header and hero |
| 72 | `mobile-scroll/02-quarter.png` | `390x844` | **Scroll Position: 02-quarter** | Mobile quarter scroll showing brand story and journey stages |
| 73 | `mobile-scroll/03-middle.png` | `390x844` | **Scroll Position: 03-middle** | Mobile middle scroll showing schedule, fares, and route timeline |
| 74 | `mobile-scroll/04-three-quarter.png` | `390x844` | **Scroll Position: 04-three-quarter** | Mobile three-quarter scroll showing sơn la story, gallery, and amenities |
| 75 | `mobile-scroll/05-bottom.png` | `390x844` | **Scroll Position: 05-bottom** | Mobile bottom viewport showing google maps, faq, final cta, and footer |
